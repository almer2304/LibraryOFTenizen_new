<?php

namespace App\Http\Controllers;

use App\Models\Borrowing;
use Illuminate\Http\Request;

class BorrowingController extends Controller
{
    private function isAdmin(Request $request)
    {
        $user = $request->user();
        return $user && $user->role === 'admin';
    }

    public function index(Request $request)
    {
        if (!$this->isAdmin($request)) {
            return response()->json(['success'=>false,'message'=>'Akses ditolak, hanya admin'],403);
        }
        $borrowing = Borrowing::with(['user', 'book'])->get();
        return response()->json([
            'success' => true,
            'data' => $borrowing
        ]);
    }

    public function store(Request $request)
    {
        $rules = [
            'book_id' => 'required|exists:book_models,id',
            'borrowed_at' => 'required|date',
            'due_date' => 'required|date|after_or_equal:borrowed_at',
            'returned_at' => 'nullable|date',
            'status' => 'required|in:borrowed,returned,overdue'
        ];

        if ($request->user() && $request->user()->role === 'admin') {
            $rules['user_id'] = 'required|exists:users,id';
        }

        $validate = $request->validate($rules);

        if (!isset($validate['user_id'])) {
            $validate['user_id'] = $request->user()->id;
        }

        $borrowing = Borrowing::create($validate);
        return response()->json([
            'success' => true,
            'message' => 'Berhasil Meminjam buku',
            'data' => $borrowing
        ], 201);
    }

    public function show(Request $request, Borrowing $borrowing)
    {
        if (!$this->isAdmin($request) && $request->user()->id !== $borrowing->user_id) {
            return response()->json(['success'=>false,'message'=>'Akses ditolak'],403);
        }

        return response()->json(['success'=>true,'data'=>$borrowing]);
    }

    public function update(Request $request, Borrowing $borrowing)
    {
        if (!$this->isAdmin($request)) {
            return response()->json(['success'=>false,'message'=>'Akses ditolak, hanya admin'],403);
        }

        $validate = $request->validate([
            'user_id' => 'sometimes|exists:users,id',
            'book_id' => 'sometimes|exists:book_models,id',
            'borrowed_at' => 'sometimes|date',
            'due_date' => 'sometimes|date|after_or_equal:borrowed_at',
            'returned_at' => 'nullable|date',
            'status' => 'sometimes|in:borrowed,returned,overdue'
        ]);

        $borrowing->update($validate);

        return response()->json([
            'success' => true,
            'message' => 'Berhasil mengubah data peminjaman',
            'data' => $borrowing
        ]);
    }

    public function destroy(Request $request, Borrowing $borrowing)
    {
        if (!$this->isAdmin($request)) {
            return response()->json(['success'=>false,'message'=>'Akses ditolak, hanya admin'],403);
        }

        $borrowing->delete();

        return response()->json([
            'success' => true,
            'message' => 'Berhasil menghapus data peminjaman'
        ]);
    }
}
